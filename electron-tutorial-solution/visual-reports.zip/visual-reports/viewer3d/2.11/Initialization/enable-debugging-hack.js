// Hacky way to enable debugging before loading the viewer code
Autodesk = {
    Viewing: {
        Private: {
            ENABLE_DEBUG: true,
            ENABLE_TRACE: true
        }
    }
};
